import { DataTypes } from 'sequelize';
import db from "../utils/connection.js"

const Mochi = db.define('Mochi', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    flavor: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    price: {
        type: DataTypes.FLOAT,
        allowNull: false,
    },
    description: {
        type: DataTypes.STRING,
        allowNull: false,
    },
},
{
    tableName: 'mochi',
    timestamps: true,
});

export default Mochi;
