import {DataTypes} from "sequelize";
import db from "../utils/connection.js";
import Mochi from "./MochiModels.js";

const User = db.define(
    "User",
    {
    userId: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false,
    },
},
    {
        tableName: "user",
    },
);
User.hasMany( Mochi, {
    foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
User.belongsTo( Mochi, {
    foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
// await User.sync({force:true});

export default User;