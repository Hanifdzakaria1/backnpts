import Payment from "../models/PaymentModels.js";
import User from "../models/UserModels.js";
import Mochi from "../models/MochiModels.js";

export const createUser = async (req, res) => {
    try {
      const { userId, name, email } = req.body;
      const user = await User.create(
        { userId, name, email }
      );
      res.status(201).json(user);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };
  
  export const updateUser = async (req, res) => {
    try {
    //   const { id } = req.params;
      const { userId, name, email } = req.body;
      const [updated] = await Order.update(
        {  userId, name, email  },
        { where: { id } }
      );
      if (updated) {
        const updateUser = await User.findByPk(id);
        res.status(200).json(updateUser);
      } else {
        res.status(404).json({ message: "Order Tidak Ditemukan" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };

  export const deleteUser = async (req, res) => {
    try {
      // const { id } = req.params;
      const { userId, name, email } = req.body;
      // const deleted = await Mochi.destroy({ where: { id } });
      const [deleted] = await User.destroy(
        {  userId, name, email },
        { where: { id } }
      );
      if (deleted) {
        res.status(204).end();
      } else {
        res.status(404).json({ message: "User Tidak Ditemukan" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };

  export const getUser = async (req, res) => {
    try {
      const order = await User.findAll();
      res.status(200).json(order);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };

  export const getOrderById = async (req, res) => {
    try {
      // const { id } = req.params;
      const { userId, name, email } = req.body;
      // const mochi = await Mochi.findByPk(id);
      const [findByPk] = await User.findByPk(
        { userId, name, email },
        { where: { id } }
      );
      if (!user) return res.status(404).json({ message: "User tidak ditemukan" });
      res.status(200).json(film);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };