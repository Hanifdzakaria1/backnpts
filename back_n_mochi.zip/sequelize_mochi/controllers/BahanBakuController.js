import BahanBaku from "../models/BahanModels.js";
import Payment from "../models/PaymentModels.js";
import User from "../models/UserModels.js";

export const createBahanBaku = async (req, res) => {
    try {
      const { BahanBakuId, TepungKanji, TepungKetan, PastaCoklat, SelaiCoklat } = req.body;
      const order = await Order.create(
        { BahanBakuId, TepungKanji, TepungKetan, PastaCoklat, SelaiCoklat }
      );
      res.status(201).json(order);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };
  // TepungKanji, TepungKetan, PastaCoklat, SelaiCoklat
  export const updateBahanBaku = async (req, res) => {
    try {
    //   const { id } = req.params;
      const { BahanBakuId, TepungKanji, TepungKetan, PastaCoklat, SelaiCoklat } = req.body;
      const [updated] = await Order.update(
        {  BahanBakuId, TepungKanji, TepungKetan, PastaCoklat, SelaiCoklat  },
        { where: { id } }
      );
      if (updated) {
        const updateOrder = await Order.findByPk(id);
        res.status(200).json(updateOrder);
      } else {
        res.status(404).json({ message: "Bahan Baku Tidak Ditemukan" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };

  export const deleteBahanBaku = async (req, res) => {
    try {
      // const { id } = req.params;
      const { BahanBakuId, TepungKanji, TepungKetan, PastaCoklat, SelaiCoklat } = req.body;
      // const deleted = await Mochi.destroy({ where: { id } });
      const [deleted] = await Order.destroy(
        { BahanBakuId, TepungKanji, TepungKetan, PastaCoklat, SelaiCoklat },
        { where: { id } }
      );
      if (deleted) {
        res.status(204).end();
      } else {
        res.status(404).json({ message: "Bahan Baku Tidak Ditemukan" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };

  export const getBahanBaku = async (req, res) => {
    try {
      const order = await Order.findAll();
      res.status(200).json(order);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };

  export const getOrderById = async (req, res) => {
    try {
      // const { id } = req.params;
      const { BahanBakuId, TepungKanji, TepungKetan, PastaCoklat, SelaiCoklat } = req.body;
      // const mochi = await Mochi.findByPk(id);
      const [findByPk] = await Order.findByPk(
        { BahanBakuId, TepungKanji, TepungKetan, PastaCoklat, SelaiCoklat },
        { where: { id } }
      );
      if (!order) return res.status(404).json({ message: "Bahan Baku tidak ditemukan" });
      res.status(200).json(film);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };