import Payment from "../models/PaymentModels.js";
import User from "../models/UserModels.js";
import Mochi from "../models/MochiModels.js";

export const createPayment = async (req, res) => {
    try {
      const { orderId, PaymentMethod, paymentStatus, paymentDate } = req.body;
      const payemnt = await Payment.create(
        { orderId, PaymentMethod, paymentStatus, paymentDate }
      );
      res.status(201).json(payemnt);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };
  
  export const updatePayment = async (req, res) => {
    try {
    //   const { id } = req.params;
      const { orderId, PaymentMethod, paymentStatus, paymentDate } = req.body;
      const [updated] = await Payment.update(
        {  orderId, PaymentMethod, paymentStatus, paymentDate  },
        { where: { id } }
      );
      if (updated) {
        const updatePayment = await Payment.findByPk(id);
        res.status(200).json(updatePayment);
      } else {
        res.status(404).json({ message: "Payment Tidak Ditemukan" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };

  export const deletePayment = async (req, res) => {
    try {
      // const { id } = req.params;
      const { orderId, PaymentMethod, paymentStatus, paymentDate } = req.body;
      // const deleted = await Mochi.destroy({ where: { id } });
      const [deleted] = await Payment.destroy(
        {  orderId, PaymentMethod, paymentStatus, paymentDate },
        { where: { id } }
      );
      if (deleted) {
        res.status(204).end();
      } else {
        res.status(404).json({ message: "Payment Tidak Ditemukan" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };

  export const getPayment = async (req, res) => {
    try {
      const payment = await Payment.findAll();
      res.status(200).json(payment);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };

  export const getPaymentById = async (req, res) => {
    try {
      // const { id } = req.params;
      const { orderId, PaymentMethod, paymentStatus, paymentDate } = req.body;
      // const mochi = await Mochi.findByPk(id);
      const [findByPk] = await Payment.findByPk(
        { orderId, PaymentMethod, paymentStatus, paymentDate },
        { where: { id } }
      );
      if (!paynet) return res.status(404).json({ message: "Payment tidak ditemukan" });
      res.status(200).json(film);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };

