import Mochi from "../models/MochiModels.js";
import User from "../models/UserModels.js";
import clean from "./helpers/clean.js";

const createSeeder = async () => {
    await clean();
    const user = await User.create({
        name:"hanhan",
        email:"hanhan@gmail.com",
    });

    const mochi1 = await Mochi.create({
        name:"mochi original",
        flavor:"Tiramisu flavored ",
        price:"Rp 9000",
        description:"Nikmati sensasi unik Mochi rasa Original Tiramisu! Perpaduan tekstur kenyal mochi dengan rasa tiramisu yang kaya, lembut, dan manis menghadirkan pengalaman pencuci mulut yang mewah. Cocok untuk menemani momen santai Anda. Cicipi kelezatan tiada duanya hari ini!",
        UserId:user.dataValues.id,
    });

    const mochi2 = await Mochi.create({
        name:"mochi pandan",
        flavor:"Chocolate flavored ",
        price:"Rp 5000",
        description:"Mochi rasa coklat adalah makanan ringan khas Jepang yang terbuat dari adonan ketan lembut dan kenyal, dengan isian atau lapisan coklat manis di dalamnya. Teksturnya yang elastis dipadukan dengan rasa coklat yang kaya memberikan perpaduan unik antara kelembutan dan manis yang memanjakan lidah. Cocok dinikmati sebagai camilan atau pencuci mulut.",
        UserId:user.dataValues.id,
    });

    const findmyMochiByUser = await Mochi.findAll({
        where:{
            UserId: user.dataValues.id
        },
        attributes: ["name", "flavor", "price", "descrption", "UserId"]
    });

    return {user, findmyMochiByUser};
};

// const deleteUser = async (id) => {
//     await User.destroy({
//         where: {
//             id: id,
//         }
//     });
// };

// const updateUser = async (id) = {
//     await User.update(
//         {
//             name: "supri",
//             email: "supro@gmail.com",
//         },
//         {
            
//         },
//     )
// }

const {mochi} = await createSeeder();
console.log("=== INI ADALAH DATA USER ===");
console.log(mochi);
console.log("=== INI ADALAH DATA MOCHI ===");
mochis.map((item) => {
    console.log(item.dataValues)
});
// export default createSeeder;